import os
import json
import pickle
import boto3
import random
import requests

def get_username_from_addresses(addresses):
    url = "https://api.neynar.com/v2/farcaster/user/bulk-by-address"
    
    headers = {
        "accept": "application/json",
        "api_key": "NEYNAR_API_DOCS"
    }
    
    params = {
        "addresses": ",".join(addresses),
        "address_types": "verified_addresses"
    }
    
    response = requests.get(url, headers=headers, params=params)
    return response.json()

def _extract_usernames(response_data):
    usernames = {}
    for address, user_data in response_data.items():
        if user_data:
            username = user_data[0].get('username', 'no_farcaster_name')
            usernames[address] = username
        else:
            usernames[address] = 'no_farcaster_name'
    return usernames

def get_delegates_usernames(random_delegates):
    addresses = [delegate['address'] for delegate in random_delegates]
    response_data = get_username_from_addresses(addresses)
    usernames = _extract_usernames(response_data)
    
    for delegate in random_delegates:
        delegate['username'] = usernames.get(delegate['address'], 'no_farcaster_name')
    
    return random_delegates

def lambda_handler(event, context):
    # Initialize S3 client
    s3 = boto3.client('s3')

    # S3 bucket and file details
    bucket_name = 'superhack-frame'
    good_delegates_file_key = 'good_delegates.pkl'

    # Download the good_delegates file from S3
    s3_response = s3.get_object(Bucket=bucket_name, Key=good_delegates_file_key)
    file_content = s3_response['Body'].read()

    # Load the good_delegates pickle file
    good_delegates_dict = pickle.loads(file_content)

    # Filter good delegates
    good_delegates = [{"address": addr} for addr, is_good in good_delegates_dict.items() if is_good]

    # Randomly select 3 good delegates
    random_delegates = random.sample(good_delegates, min(3, len(good_delegates)))

    # Get usernames for the random delegates
    result = get_delegates_usernames(random_delegates)

    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }
